package view;

/**
 * ImageView interface shows the display of the Image and the method renderMessage.
 */
public interface ImageView {


}
