package model;

/**
 * This interface represents different operations that an Image model must support to return various
 * aspects of its state.
 */
public interface Image {

}
