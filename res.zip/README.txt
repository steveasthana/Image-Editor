Astitva Asthana and Anjali Tanna HW07.
Created 6/11/21.
Last updated 6/26/21.

********From HW05:

colorTransformation package:

Starting with the Color Transformations, we have an interface IColorTransformations that all 
future transformations can implement. The abstract class AColorTransformation implements the interface and
has a 2D array to represent the matrix of the color transformation, and also has a method that applies the 
transformation to a given pixel. The Grayscale and Sepia transformations extend this class and have 
their respective values in the matrix. All color transformations in the future can extend the abstract
class and have their respective values in the matrix. 

filterTransformation package:

For filters, we have a similar design with an abstract class AFilter that again has a 2D array
to represent a matrix for the kernel of any filter. All filters in the future can extend this class
and use their kernel as a matrix. The Blur and Sharpen classes extend the abstract class with 
their kernels as the matrix.

Model Package:

We next have an interface Image to represent all future images. The abstract class AImage implements this interface
and is extended by all future image types. The interface contains methods to apply Sepia, Blur, Grayscale, and Sharpen,
which the PPM class which extends the abstract class also implements. This will make all future image types be able to apply 
the filters and transformations. The PPM image has a list of lists of pixels to represent each row of pixels in a list.

A Pixel has three fields, which represent the red, green, and blue values. Values will be clamped to 0 and 255 if they are lower 
or greater than the bounds.

A Color was an enum created that represents a few colors, with the corresponding Pixel with the rgb values matching the color. This
was created primarily for the checkerboard method which takes two colors as the tile colors on the board when being created.

The ImageUtil allows for images to be converted to a new AImage, with the type depending on the type of image provided. Currently,
the ImageUtil only reads ppm images.

The IWriter is an interface designed to provide a way to write images as a file that is then readable by an image editor. The PPM Writer
class implements this interface, and creates the methods from the interface, createNewFile and writeFile. createNewFile creates a new file based on
a filename given, while write file takes an AImage and writes all the information from the AImage into the format for the image onto the file 
so that it is readable by an image editor.

The main class had the sole purpose of running methods that could write files and create new files to produce the filtered and transformed pictures.

Supported functionality:
- Loading and saving PPM images.
- Applying a blur, sharpen, sepia, or grayscale to a PPM image.
- Programatically creating a checkerboard image, given the width of a tile in pixels, the number of tiles in a row, and two colors for the tiles.

All example pictures were blurred more than once to ensure that the filter was working.
The rest of the filters and transformations were only applied once to each image.


For the images we used as examples, we own both the images and are authorizing the usage of them for this project.

*********From HW06:

Changes introduced in HW06 editing code from HW05:

- The AImage constructor was changed to include the list of lists of pixels, since each image type will have a filename and that list.
  this makes it easier to add new image types since they will all have what is already included in the abstract class the
  specific image type will extend.
- The applyFilter and applyColorTransformation methods in the AImage class were made public. Beforehand they were private 
  since they were solely used to apply the filters and color transformations we have created on PPMs. Now, we have made them 
  public so that layered images can use two methods total to apply all future filters and color transformations. 
- The IWriter interface and PPMWriter were moved to the controller package, since they handle I/O, which should not be present in the model package.
- In the model package we added a FileType enum, which has each supported filetype, with each PileType tied to the ending of a filename for that filetype.
  For example, PNG is tied to ".png".
- The methods to apply all filters and transformations to PPMs were moved from the PPM class to the AImage class, so that all future images
  can utilize the same methods.
- Added an abstract class AWriter, so that all file writers can extend the class and use the same createNewFile method.
- Removed methods from the interface level for the Image, which allows LayeredImages to implement the interface while having their unique functionality 
  compared to the rest of the image type, which are singular files.

Controller Package:

The classes PNGWriter and JPEGWriter now extend AWriter, since they are all classes that handle the saving and exporting of singular images.
The class LayerWriter implements IWriter, since the methods that are required to export and save layers are different than those required
for singlular images.

The interface ImageController is created so that our implementation of a controller can implement the interface.
The SimpleImageController implements the ImageController interface, and contains our methods for handling scripts full of commands
to use the image editor. This class is our main controller class to run the editor, and contains multiple fields which allow methods
from the model to be run successfully.



Model Package:

The ImageUtil class contains methods to interpret PNG, JPEG, and layered images.
The LayeredImage class implements Image since it represents an editable format of image for our editor. This class contains one field, which is an 
ArrayList<Layer>. This list represents the layers present in the layered image. The constructor of the LayeredImage throws an error if 
each layer in the list of layers does not have the same dimensions. Each layer has a boolean to represent whether the layer is visible, 
the FileType of the layer, and the actual image that the layer represents. The constructor throws exceptions if the file type or the image is null.

The PNG and JPEG classes extend the AImage class, and have the same fields as all other AImages. They each have their own respective save methods 
that are overriden from AImage, since the save method creates an AWriter of the respective type of file. (i.e. new PNGWriter for PNGs). These methods
DO NOT directly handle I/O since this is in the method class, but rather call upon the writers to do whatever is required.


View Package:
The view package contains the interface ImageView which represents something that all future views of our models and editors can implement. 
Our current main view class is the SimpleImageView, which only has a method that allows the controller to render messages to the user. 
The field for this class is an Appendable.


New supported functionality in addition to functionality from HW05:
- Creating, saving, and l a LayeredImage. In a layered image, images can be removed and added, and can be applied filters and color transformations.
    - Saving a multi layered image creates a file which has all the information of all the layers within the image, and saves the images as separate files as well.
    - Just the top layer of a multi layered image may be saved as well. 
    - Layers can be set to visible or invisible.
- Saving and loading JPEG and PNG files, while also applying filters and color transformations to them
- Files can be converted to different file types and saved as such.

**********HW07:

Changes introduced in HW07 editing code from HW06 and HW05:
- The ImageView interface was changed to not include the renderMessage method which was used in the SimpleImageView. This way the new view could implement the 
  ImageView without having to implement a method that would be essentially useless to the new view class.
- Similar to the first bullet point, the ImageController interface was also changed to exclude the start method, so that the new controller could implement 
  the interface without having to implement a useless method.

View Package:

In the view package we have created a new view as a class, called the ScreenView, which is a view that allows the user to view the Graphical User Interface (GUI)
for the image editor. This class has fields for components present on the GUI, which are built using helper methods that are then called in the constructor, so 
that the constructor is not too crowded with many lines of code. Rather, scrolling through the constructor should be brief and provides an idea 
as to what "physical" components are present on the GUI. This class implements ActionListener and ImageView, the latter of which just allows for us to 
know that the view is supported for our particular image editor. As for the former, it allows the class to have a method to handle responses to actions
made by the user, which are mainly clicks of options on menus and inputting text. Besides the method to handle these actions and the methods that help 
build parts of the GUI itself, there is an addImage method, which allows for the view to refresh the image that is being displayed. 

Controller Package:

In the controller package, we added a new controller class, ScreenImageController, which allows us to use the new GUI view and the model associated with the image
or layered image being edited. Methods within this controller allow for a filename from the view to be read as an Image, so that we can apply filters, color transformations, 
and utilize layer operations on the respective Image (represents an AImage or LayeredImage). To do so, the Controller takes in the filename that the user selects, and 
uses the methods present in the model to gather information that it can send back to the view. 

Most recently updated functionality in addition to functionality from HW05 and HW06:
- A GUI that supports all previous uses of the image editor.
  - The File submenu includes:
    - A save optionthat saves the file with the filename already present
    - A Save As optionwhich allows the user to pick a location to save to as a certain file type. 
    - A Load option which has a submenu to allow them to choose from a singular image, command file, or layered image to load
	- If the user selects layered image or command file, the popup will only allow the user to select text files to load in, wehereas otherwise will allow jpgs and pngs
    - A Make Layered button allows the user to make the current image being edited into a layered image
  - The apply submenu has all the color transformations and filters
  - The Layer submenu includes:
    - An option to add a layer, which brings up a popup menu of the directories on a device, from which the user can choose any ppm, jpg, or png file
    - An option to remove a layer, which then prompts the user for a number, indicating the layer number to remove
